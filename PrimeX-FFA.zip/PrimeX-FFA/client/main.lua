local inFFA = false
local currentArena = nil
local currentClass = nil
local kills = 0
local deaths = 0
local lastSpawn = nil

--------------------------------------------------------
-- RANDOM SPAWN SYSTEM
--------------------------------------------------------

function GetRandomSpawn(arena, deathCoords)

    local validSpawns = {}

    for index, spawn in pairs(arena.spawns) do

        local spawnCoords = vec3(
            spawn.x,
            spawn.y,
            spawn.z
        )

        local distance =
            #(spawnCoords - deathCoords)

        -- Avoid nearby spawn
        if distance > 80.0 then

            table.insert(validSpawns, {
                index = index,
                spawn = spawn
            })

        end
    end

    -- Fallback
    if #validSpawns <= 0 then

        for index, spawn in pairs(arena.spawns) do

            table.insert(validSpawns, {
                index = index,
                spawn = spawn
            })

        end
    end

    local selected

    repeat

        selected =
            validSpawns[
                math.random(#validSpawns)
            ]

    until selected.index ~= lastSpawn
        or #validSpawns <= 1

    lastSpawn = selected.index

    return selected.spawn
end

--------------------------------------------------------
-- MENU OPEN SYSTEM
--------------------------------------------------------

CreateThread(function()

    while true do

        local sleep = 1000

        local coords =
            GetEntityCoords(cache.ped)

        if #(coords - vec3(
            Config.MenuLocation.x,
            Config.MenuLocation.y,
            Config.MenuLocation.z
        )) < 5.0 then

            sleep = 0

            lib.showTextUI(
                '[E] Open FFA Menu'
            )

            if IsControlJustReleased(
                0,
                Config.OpenKey
            ) then

                OpenArenaMenu()

            end
        else
            lib.hideTextUI()
        end

        Wait(sleep)
    end
end)

--------------------------------------------------------
-- MAP MENU
--------------------------------------------------------

function OpenArenaMenu()

    local options = {}

    for index, arena in pairs(Config.Maps) do

        local players =
            GlobalState[
                'ffa_' .. arena.name
            ] or 0

        table.insert(options, {

            title = arena.name,

            description = (
                'Players: %s/%s'
            ):format(
                players,
                arena.maxPlayers
            ),

            icon = 'gun',

            onSelect = function()
                OpenClassMenu(index)
            end
        })
    end

    lib.registerContext({
        id = 'ffa_maps',
        title = 'PrimeX FFA',
        options = options
    })

    lib.showContext('ffa_maps')
end

--------------------------------------------------------
-- CLASS MENU
--------------------------------------------------------

function OpenClassMenu(arenaIndex)

    local arena =
        Config.Maps[arenaIndex]

    local options = {}

    for _, class in pairs(arena.classes) do

        table.insert(options, {

            title = class.label,
            icon = 'crosshairs',

            onSelect = function()

                JoinFFA(
                    arenaIndex,
                    class
                )

            end
        })
    end

    lib.registerContext({
        id = 'ffa_classes',
        title = arena.name,
        options = options
    })

    lib.showContext('ffa_classes')
end

--------------------------------------------------------
-- JOIN FFA
--------------------------------------------------------

function JoinFFA(arenaIndex, class)

    local arena =
        Config.Maps[arenaIndex]

    inFFA = true
    currentArena = arena
    currentClass = class

    TriggerServerEvent(
        'primexffa:joinArena',
        arena.name
    )

    local spawn =
        GetRandomSpawn(
            arena,
            vec3(0.0, 0.0, 0.0)
        )

    DoScreenFadeOut(500)

    while not IsScreenFadedOut() do
        Wait(0)
    end

    SetEntityCoords(
        cache.ped,
        spawn.x,
        spawn.y,
        spawn.z,
        false,
        false,
        false,
        true
    )

    SetEntityHeading(
        cache.ped,
        spawn.w
    )

    Wait(500)

    DoScreenFadeIn(500)

    TriggerServerEvent(
        'primexffa:giveWeapon',
        class.weapon
    )

    SendNUIMessage({
        action = 'show',
        kills = kills,
        deaths = deaths,
        kd = kills / math.max(deaths, 1),
        map = arena.name,
        ammo = 0,
        clip = 0
    })

    lib.notify({
        title = 'FFA',
        description =
            'Joined ' .. arena.name,
        type = 'success'
    })
end

--------------------------------------------------------
-- QUIT FFA
--------------------------------------------------------

RegisterCommand(
    Config.ExitCommand,

    function()

        if not inFFA then
            return
        end

        TriggerServerEvent(
            'primexffa:leaveArena',
            currentArena.name
        )

        inFFA = false
        currentArena = nil
        currentClass = nil

        -- RESET STATS
        kills = 0
        deaths = 0

        DoScreenFadeOut(500)

        while not IsScreenFadedOut() do
            Wait(0)
        end

        SetEntityCoords(
            cache.ped,
            Config.MenuLocation.x,
            Config.MenuLocation.y,
            Config.MenuLocation.z
        )

        Wait(500)

        DoScreenFadeIn(500)

        SendNUIMessage({
            action = 'hide'
        })

        lib.notify({
            title = 'FFA',
            description =
                'You Left FFA',
            type = 'error'
        })
    end
)

--------------------------------------------------------
-- RED ZONE DRAW
--------------------------------------------------------

CreateThread(function()

    while true do

        Wait(0)

        if inFFA and currentArena then

            DrawMarker(
                1,
                currentArena.zone.x,
                currentArena.zone.y,
                currentArena.zone.z - 15.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                currentArena.radius * 2.0,
                currentArena.radius * 2.0,
                25.0,
                255,
                0,
                0,
                120,
                false,
                false,
                2,
                false,
                nil,
                nil,
                false
            )
        end
    end
end)

--------------------------------------------------------
-- OUTSIDE ZONE KILL
--------------------------------------------------------

CreateThread(function()

    while true do

        Wait(1000)

        if inFFA and currentArena then

            local coords =
                GetEntityCoords(cache.ped)

            if #(
                coords - currentArena.zone
            ) > currentArena.radius then

                SetEntityHealth(
                    cache.ped,
                    0
                )
            end
        end
    end
end)

--------------------------------------------------------
-- KILL COUNTER
--------------------------------------------------------

AddEventHandler(
    'gameEventTriggered',

    function(name, args)

        if not inFFA then
            return
        end

        if name ==
            'CEventNetworkEntityDamage'
        then

            local victim = args[1]
            local attacker = args[2]

            if attacker == cache.ped
            and victim ~= attacker then

                if IsEntityAPed(victim)
                and IsPedAPlayer(victim) then

                    if GetEntityHealth(victim)
                        <= 0 then

                        kills = kills + 1

                        local weapon =
                            GetSelectedPedWeapon(
                                cache.ped
                            )

                        local ammo =
                            GetAmmoInPedWeapon(
                                cache.ped,
                                weapon
                            )

                        local _, clip =
                            GetAmmoInClip(
                                cache.ped,
                                weapon
                            )

                        SendNUIMessage({
                            action = 'update',
                            kills = kills,
                            deaths = deaths,
                            kd = kills / math.max(deaths, 1),
                            map = currentArena.name,
                            ammo = ammo,
                            clip = clip
                        })
                    end
                end
            end
        end
    end
)

--------------------------------------------------------
-- DEATH / RANDOM RESPAWN
--------------------------------------------------------

AddEventHandler(
    'esx:onPlayerDeath',

    function()

        if not inFFA then
            return
        end

        deaths = deaths + 1

        local deathCoords =
            GetEntityCoords(cache.ped)

        Wait(Config.ReviveTime)

        local spawn =
            GetRandomSpawn(
                currentArena,
                deathCoords
            )

        DoScreenFadeOut(500)

        while not IsScreenFadedOut() do
            Wait(0)
        end

        TriggerEvent(
            'esx_ambulancejob:revive'
        )

        Wait(1000)

        NetworkResurrectLocalPlayer(
            spawn.x,
            spawn.y,
            spawn.z,
            spawn.w,
            true,
            false
        )

        SetEntityCoords(
            cache.ped,
            spawn.x,
            spawn.y,
            spawn.z,
            false,
            false,
            false,
            true
        )

        SetEntityHeading(
            cache.ped,
            spawn.w
        )

        ClearPedBloodDamage(cache.ped)
        ClearPedTasksImmediately(cache.ped)

        TriggerServerEvent(
            'primexffa:giveWeapon',
            currentClass.weapon
        )

        local weapon =
            GetSelectedPedWeapon(
                cache.ped
            )

        local ammo =
            GetAmmoInPedWeapon(
                cache.ped,
                weapon
            )

        local _, clip =
            GetAmmoInClip(
                cache.ped,
                weapon
            )

        SendNUIMessage({
            action = 'update',
            kills = kills,
            deaths = deaths,
            kd = kills / math.max(deaths, 1),
            map = currentArena.name,
            ammo = ammo,
            clip = clip
        })

        Wait(500)

        DoScreenFadeIn(500)

        lib.notify({
            title = 'FFA',
            description =
                'Respawned At Random Location',
            type = 'success'
        })
    end
)

--------------------------------------------------------
-- LIVE AMMO HUD
--------------------------------------------------------

CreateThread(function()

    while true do

        Wait(100)

        if inFFA and currentArena then

            local weapon =
                GetSelectedPedWeapon(
                    cache.ped
                )

            local ammo =
                GetAmmoInPedWeapon(
                    cache.ped,
                    weapon
                )

            local _, clip =
                GetAmmoInClip(
                    cache.ped,
                    weapon
                )

            SendNUIMessage({
                action = 'update',
                kills = kills,
                deaths = deaths,
                kd = kills / math.max(deaths, 1),
                map = currentArena.name,
                ammo = ammo,
                clip = clip
            })
        end
    end
end)