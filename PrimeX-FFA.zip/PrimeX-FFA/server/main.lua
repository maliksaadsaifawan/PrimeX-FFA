local arenaPlayers = {}
local playerFFAWeapons = {}

--------------------------------------------------------
-- PLAYER COUNTER
--------------------------------------------------------

function CountPlayers(tbl)

    local count = 0

    for _ in pairs(tbl) do
        count = count + 1
    end

    return count
end

--------------------------------------------------------
-- JOIN ARENA
--------------------------------------------------------

RegisterNetEvent(
    'primexffa:joinArena',

    function(arenaName)

        local src = source

        arenaPlayers[arenaName] =
            arenaPlayers[arenaName] or {}

        arenaPlayers[arenaName][src] = true

        GlobalState[
            'ffa_' .. arenaName
        ] = CountPlayers(
            arenaPlayers[arenaName]
        )

        print((
            '[PrimeX FFA] %s joined %s'
        ):format(
            GetPlayerName(src),
            arenaName
        ))
    end
)

--------------------------------------------------------
-- LEAVE ARENA
--------------------------------------------------------

RegisterNetEvent(
    'primexffa:leaveArena',

    function(arenaName)

        local src = source

        -- REMOVE PLAYER
        if arenaPlayers[arenaName] then

            arenaPlayers[arenaName][src] = nil

            GlobalState[
                'ffa_' .. arenaName
            ] = CountPlayers(
                arenaPlayers[arenaName]
            )
        end

        -- REMOVE WEAPON
        if playerFFAWeapons[src] then

            exports.ox_inventory:RemoveItem(
                src,
                playerFFAWeapons[src],
                1
            )

            playerFFAWeapons[src] = nil
        end

        print((
            '[PrimeX FFA] %s left %s'
        ):format(
            GetPlayerName(src),
            arenaName
        ))
    end
)

--------------------------------------------------------
-- GIVE FFA WEAPON
--------------------------------------------------------

RegisterNetEvent(
    'primexffa:giveWeapon',

    function(weapon)

        local src = source

        -- REMOVE OLD WEAPON
        if playerFFAWeapons[src] then

            exports.ox_inventory:RemoveItem(
                src,
                playerFFAWeapons[src],
                1
            )
        end

        playerFFAWeapons[src] = weapon

        -- GIVE NEW WEAPON
        exports.ox_inventory:AddItem(
            src,
            weapon,
            1,
            {
                ammo = 1000
            }
        )

        print((
            '[PrimeX FFA] Gave %s to %s'
        ):format(
            weapon,
            GetPlayerName(src)
        ))
    end
)

--------------------------------------------------------
-- PLAYER DISCONNECT
--------------------------------------------------------

AddEventHandler(
    'playerDropped',

    function()

        local src = source

        -- REMOVE FROM ARENAS
        for arenaName, players in pairs(arenaPlayers) do

            if players[src] then

                players[src] = nil

                GlobalState[
                    'ffa_' .. arenaName
                ] = CountPlayers(players)

                print((
                    '[PrimeX FFA] %s disconnected from %s'
                ):format(
                    GetPlayerName(src) or src,
                    arenaName
                ))
            end
        end

        -- REMOVE WEAPON
        if playerFFAWeapons[src] then

            exports.ox_inventory:RemoveItem(
                src,
                playerFFAWeapons[src],
                1
            )

            playerFFAWeapons[src] = nil
        end
    end
)

--------------------------------------------------------
-- SAFETY CLEANUP ON RESOURCE STOP
--------------------------------------------------------

AddEventHandler(
    'onResourceStop',

    function(resource)

        if resource ~= GetCurrentResourceName() then
            return
        end

        for src, weapon in pairs(playerFFAWeapons) do

            exports.ox_inventory:RemoveItem(
                src,
                weapon,
                1
            )
        end

        print('[PrimeX FFA] Cleaned all FFA weapons.')
    end
)