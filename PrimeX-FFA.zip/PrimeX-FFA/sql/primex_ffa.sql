
CREATE TABLE IF NOT EXISTS primex_ffa_stats (
    identifier VARCHAR(60) NOT NULL,
    kills INT DEFAULT 0,
    deaths INT DEFAULT 0,
    PRIMARY KEY(identifier)
);
