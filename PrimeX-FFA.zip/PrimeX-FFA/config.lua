
Config = {}

Config.OpenKey = 38
Config.ExitCommand = 'quitffa'
Config.ReviveTime = 3000

Config.MenuLocation = vec4(-313.14, -1033.89, 30.53, 160.93)

Config.Maps = {

    {
        name = 'Pistol Arena',
        maxPlayers = 15,
        zone = vec3(-193.74, -227.37, 78.34),
        radius = 60.0,

        classes = {
            {
                label = 'Heavy Pistol',
                weapon = 'weapon_heavypistol'
            },

            {
                label = 'AP Pistol',
                weapon = 'weapon_appistol'
            },

            {
                label = 'Desert Eagle',
                weapon = 'weapon_pistol50'
            }
        },

        spawns = {
            vec4(-193.74, -227.37, 78.34, 169.23),
            vec4(-207.23, -234.35, 78.34, 292.24),
            vec4(-174.03, -265.87, 81.64, 305.16),
            vec4(-174.78, -209.75, 78.34, 71.47),
            vec4(-140.12, -216.42, 81.83, 142.26),
            vec4(-217.18, -186.13, 85.22, 245.56)
        }
    },

    {
        name = 'AR Arena',
        maxPlayers = 15,
        zone = vec3(-193.74, -227.37, 78.34),
        radius = 60.0,

        classes = {
            {
                label = 'Carbine Rifle',
                weapon = 'weapon_carbinerifle'
            },

            {
                label = 'AK-47',
                weapon = 'weapon_assaultrifle'
            },

            {
                label = 'Special Carbine',
                weapon = 'weapon_specialcarbine'
            }
        },

        spawns = {
            vec4(-193.74, -227.37, 78.34, 169.23),
            vec4(-207.23, -234.35, 78.34, 292.24),
            vec4(-174.03, -265.87, 81.64, 305.16),
            vec4(-174.78, -209.75, 78.34, 71.47),
            vec4(-140.12, -216.42, 81.83, 142.26),
            vec4(-217.18, -186.13, 85.22, 245.56)
        }
    },

    {
        name = 'Shotgun Arena',
        maxPlayers = 15,
        zone = vec3(-193.74, -227.37, 78.34),
        radius = 100.0,

        classes = {
            {
                label = 'Pump Shotgun',
                weapon = 'weapon_pumpshotgun'
            },

            {
                label = 'Combat Shotgun',
                weapon = 'weapon_combatshotgun'
            },

            {
                label = 'Sawn Off',
                weapon = 'weapon_sawnoffshotgun'
            }
        },

        spawns = {
            vec4(-193.74, -227.37, 78.34, 169.23),
            vec4(-207.23, -234.35, 78.34, 292.24),
            vec4(-174.03, -265.87, 81.64, 305.16),
            vec4(-174.78, -209.75, 78.34, 71.47),
            vec4(-140.12, -216.42, 81.83, 142.26),
            vec4(-217.18, -186.13, 85.22, 245.56)
        }
    }
}
