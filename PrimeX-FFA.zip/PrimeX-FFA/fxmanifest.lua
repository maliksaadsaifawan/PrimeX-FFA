
fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'JeaSon MaLik'
description 'Prime X Roleplay Enhanced Advanced FFA V2'
version '2.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/script.js'
}

dependencies {
    'ox_lib',
    'ox_inventory',
    'es_extended',
    'esx_ambulancejob'
}
