const hud = document.getElementById('hud');

function animateValue(element, start, end, duration) {
    let startTimestamp = null;

    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;

        const progress = Math.min((timestamp - startTimestamp) / duration, 1);

        const value = progress * (end - start) + start;

        element.innerText = Number(value).toFixed(2);

        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };

    window.requestAnimationFrame(step);
}

window.addEventListener('message', function(event) {

    const data = event.data;

    if (!data) return;

    // SHOW
    if (data.action === 'show') {
        hud.style.display = 'flex';
    }

    // HIDE
    if (data.action === 'hide') {
        hud.style.display = 'none';
        return;
    }

    // UPDATE
    if (data.action === 'show' || data.action === 'update') {

        const kills = Number(data.kills ?? 0);
        const deaths = Number(data.deaths ?? 0);

        // KILLS
        document.getElementById('kills').innerText = kills;

        // DEATHS
        document.getElementById('deaths').innerText = deaths;

        // KD
        let kd = data.kd;

        if (kd === undefined || kd === null) {
            kd = deaths === 0 ? kills : (kills / deaths);
        }

        const kdElement = document.getElementById('kd');

        const currentKD = parseFloat(kdElement.innerText) || 0;

        animateValue(kdElement, currentKD, kd, 300);

        // AMMO
        const ammo = data.ammo ?? 0;
        const clip = data.clip ?? 0;

        document.getElementById('ammo').innerText = `${clip} / ${ammo}`;
    }
});